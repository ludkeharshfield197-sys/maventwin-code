"""Compare existing in-memory capture stages for the twelve unresolved repositories."""
from pathlib import Path
import csv,json,sys,shutil,xml.etree.ElementTree as ET,collections
R=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[2]
O=Path(sys.argv[2]) if len(sys.argv)>2 else R/'supplementary_results'
S=O/'supplemental_20261004/provenance_trace';S.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(R/'scripts'))
from final_evidence_runner import extract_model,model_deltas
def read(p):
    return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def key(x):return x['category'],x['entity'],x['field']
groups=read(R/'artifacts/reviewer_revision/model/model_delta_summary.csv')
repos=[x['repo'] for x in groups if x['project_pom_evidence']!='true' and x['runtime_only_evidence']!='true']
rows=[x for x in read(R/'supplemental/MODEL_ABLATION_ROWS.csv') if x['repo'] in repos and x['provenance_class']=='UNKNOWN']
superpom=R/'evidence/runtime-resources/maven-model-builder-3.9.16__org_apache_maven_model_pom-4.0.0.xml'
defaults={'org.apache.maven.plugins:'+x.findtext('artifactId'):x.findtext('version') for x in ET.parse(superpom).getroot().findall('build/pluginManagement/plugins/plugin')}
result=[];captures=[]
for row in rows:
    sid=row['repo'].replace('/','__');visible=[]
    stages=[('validation_callback',O/'api_without_help/runs'/sid,'observer/000-model.xml'),
            ('help_callback',O/'instrument/runs'/sid,'observer/000-model.xml'),
            ('help_completed_after_early_planning',O/'instrument/runs'/sid,'observer/000-final-model.xml')]
    new=O/'supplemental_20261004/lifecycle_plan_all50/raw_outputs'/sid/'runs'
    stages.extend((stage,new,'observer/000-'+stage+'-model.xml') for stage in ['participant-callback','participants-complete','measurement-complete','plans-complete'])
    for stage,base,name in stages:
        files=[base/f'{rt}-r{n}'/name for rt,n in [('m3',1),('m4',1),('m4',2),('m3',2)]]
        if all(p.exists() for p in files):
            models=[extract_model(p) for p in files]
            ds=model_deltas(row['repo'],row['commit'],models[0],models[1])[1]
            match=next((x for x in ds if key(x)==key(row)),None)
            within=model_deltas(row['repo'],row['commit'],models[0],models[3])[1]+model_deltas(row['repo'],row['commit'],models[1],models[2])[1]
            visible.append((stage,bool(match),not any(key(x)==key(row) for x in within)))
            for p in files:
                dest=S/'raw_outputs'/stage/sid/p.parent.parent.name/p.name
                dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
                for log in ['command.json','stdout.txt']:
                    shutil.copy2(p.parent.parent/log,dest.parent/log)
    first=next((stage for stage,changed,stable in visible if changed and stable),'EXISTING_CAPTURE_UNAVAILABLE')
    item=dict(repository=row['repo'],delta_key='|'.join(key(row)),category=row['category'],entity=row['entity'],field=row['field'],maven3_value=row['m3_value'],maven4_value=row['m4_value'],first_stage_visible=first,source_match=False,runtime_default_match=False,extension_match=False,late_resolution_match=False,final_classification='UNRESOLVED',stage_observations=json.dumps(visible),source_detail='')
    if row['field']=='entity' and row['entity'] in defaults and json.loads(row['m4_value']) is None and json.loads(row['m3_value'])['version']==defaults[row['entity']]:
        item.update(runtime_default_match=True,final_classification='RUNTIME_DEFAULT',first_stage_visible='super-POM',source_detail=superpom.name)
    elif row['repo']=='junit-team/junit4' and row['entity'].endswith(':enforce-versions') and row['field']=='configuration':
        source=R/'final_evidence_v1/snapshots'/sid/'pom.xml'
        if '${maven.version}' in source.read_text(encoding='utf-8'):
            item.update(source_match=True,final_classification='SOURCE_LINKED',source_detail='Root-POM enforce-versions configuration interpolates maven.version; the changed field is the diagnostic message.')
    elif row['entity'].endswith(':injected-central-publishing'):
        obs={stage:(changed,stable) for stage,changed,stable in visible}
        if obs.get('participant-callback')==(False,True) and obs.get('participants-complete')==(True,True):
            item.update(extension_match=True,final_classification='LIFECYCLE_PARTICIPANT_ADDED',first_stage_visible='participants-complete',source_detail='Central Publishing afterProjectsRead model mutation; minimal counterfactual in central_publishing_minimal.')
    elif row['field']=='version':
        obs={stage:(changed,stable) for stage,changed,stable in visible}
        if obs.get('participant-callback')==(False,True) and obs.get('measurement-complete')==(True,True) and obs.get('plans-complete')==(False,True):
            item.update(late_resolution_match=True,final_classification='LATE_PLUGIN_RESOLUTION',first_stage_visible='measurement-complete',source_detail='Managed plugin version differs after help measurement and agrees after lifecycle-plan resolution; active plugin versions agree at the initial callback.')
    result.append(item)
with (S/'unresolved_provenance_trace.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(result[0]));w.writeheader();w.writerows(result)
summary=dict(repositories=len(repos),initial_unresolved_rows=len(rows),row_classes=dict(collections.Counter(x['final_classification'] for x in result)),remaining_unresolved_repositories=sorted({x['repository'] for x in result if x['final_classification']=='UNRESOLVED'}))
(S/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary))
