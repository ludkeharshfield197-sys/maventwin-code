"""Frozen-input lifecycle plans: shared materialization, offline ABBA, no deploy execution."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import csv,json,os,shutil,subprocess,sys,hashlib,zipfile
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from experiments import process,manifest,sha,read,dump,extended,RT,SETTINGS,ROOT,OUT
D=Path(__file__).resolve().parent
S=OUT/'supplemental_20261004';JAR=S/'observer-stages.jar'
ORDER=[('m3',1),('m4',1),('m4',2),('m3',2)]
def copy_tree(src,dst,**kwargs):
    cmd=['robocopy',str(src),str(dst),'/E','/MT:16','/R:0','/W:0','/NFL','/NDL','/NJH','/NJS','/NP']
    result=subprocess.run(cmd,capture_output=True)
    if result.returncode>=8:raise subprocess.CalledProcessError(result.returncode,cmd,result.stdout,result.stderr)
def remove_cache(path):
    resolved=path.resolve()
    if not resolved.is_relative_to(S.resolve()) or resolved==S.resolve():raise ValueError(str(resolved))
    shutil.rmtree(extended(resolved))
def build():
    classes=S/'observer-classes';classes.mkdir(parents=True,exist_ok=True)
    classpath=os.pathsep.join([str(Path(RT['m3'])/'lib/*'),str(Path(RT['m3'])/'boot/*')])
    cmd=[str(Path(RT['jdk'])/'bin/javac.exe'),'--release','17','-cp',classpath,'-d',str(classes),str(D/'ObserverStages.java')]
    subprocess.run(cmd,check=True)
    roles=''
    for role in ['org.apache.maven.AbstractMavenLifecycleParticipant','org.apache.maven.eventspy.EventSpy']:
        roles+=f'<component><role>{role}</role><role-hint>maventwin-stages</role-hint><implementation>org.maventwin.observer.ObserverStages</implementation><requirements><requirement><role>org.apache.maven.lifecycle.internal.LifecycleExecutionPlanCalculator</role><field-name>calculator</field-name></requirement></requirements></component>'
    p=classes/'META-INF/plexus/components.xml';p.parent.mkdir(parents=True,exist_ok=True);p.write_text('<component-set><components>'+roles+'</components></component-set>',encoding='utf-8')
    with zipfile.ZipFile(JAR,'w',zipfile.ZIP_DEFLATED) as z:
        for p in classes.rglob('*'):
            if p.is_file():z.write(p,p.relative_to(classes).as_posix())
    dump(S/'observer-build.json',dict(command=cmd,sha256=sha(JAR)))
def run(rt,src,cache,out,offline):
    home=Path(RT[rt]);java=Path(RT['jdk'])/'bin/java.exe'
    jargs=['--enable-native-access=ALL-UNNAMED'] if rt=='m4' else []
    config=src/'.mvn/jvm.config'
    if config.exists():
        import shlex
        jargs+=shlex.split(config.read_text(encoding='utf-8'))
    jargs+=['-Xmx1024m',f'-Dclassworlds.conf={home}/bin/m2.conf',f'-Dmaven.home={home}',f'-Dmaven.multiModuleProjectDirectory={src}',f'-Dmaven.ext.class.path={JAR}',f'-Dmaventwin.observer.output={out}/observer']
    if rt=='m4':jargs+=['-Dmaven.mainClass=org.apache.maven.cling.MavenCling']
    cmd=[str(java)]+jargs+['-classpath',str(next((home/'boot').glob('plexus-classworlds-*.jar'))),'org.codehaus.plexus.classworlds.launcher.Launcher','-B','-ntp','-N','-e','-s',str(SETTINGS),'-gs',str(SETTINGS),f'-Dmaven.repo.local={cache}','-Dstyle.color=never','-Dmaven.resolver.transport.http.connectTimeout=10000','-Dmaven.resolver.transport.http.requestTimeout=15000']
    if offline:cmd+=['-o']
    cmd+=['org.apache.maven.plugins:maven-help-plugin:3.5.1:effective-pom',f'-Doutput={out}/help-model.xml']
    env=os.environ.copy();env.update(JAVA_HOME=RT['jdk'],MAVEN_SKIP_RC='1',MAVEN_OPTS='',MAVEN_ARGS='')
    rec=process(cmd,src,out,150,env);rec.update(runtime=rt,offline=offline,observer_sha256=sha(JAR),planned_phases=['package','install','deploy'],executed_goal='help:effective-pom',source_pom_sha256=sha(src/'pom.xml'))
    dump(out/'command.json',rec);print(str(out.relative_to(S)),rec['exit_code'],rec['elapsed_seconds'],flush=True)
def merge(src,dst,conflicts):
    for p in src.rglob('*'):
        if not p.is_file() or p.name.endswith(('.lastUpdated','.lock')):continue
        q=dst/p.relative_to(src)
        if q.exists():
            conflicts.append(dict(path=p.relative_to(src).as_posix(),selection='KEEP_FIRST_MATERIALIZED_FILE'))
        else:q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(extended(p),extended(q))
def one(row):
    sid=row['repo'].replace('/','__');base=S/'lifecycle_plan_all50/raw_outputs'/sid
    src=ROOT/'final_evidence_v1/snapshots'/sid
    base.mkdir(parents=True,exist_ok=True)
    dump(base/'input.json',dict(repository=row['repo'],commit=row['commit'],source=str(src),root_pom_sha256=sha(src/'pom.xml'),phases=['package','install','deploy']))
    frozen=base/'frozen_repository'
    if not (base/'seed_manifest.json').exists():
        copy_tree(OUT/'seed',frozen,dirs_exist_ok=True);conflicts=[]
        seeds=[OUT/'cohort_offline_caches'/sid/rt for rt in ['m3','m4']]
        seeds += [OUT/area/sid/name for area,name in [('late_package_plans','frozen_repository'),('late_central_plans','frozen_repository'),('late_central_completed','frozen_repository')]]
        for seed in seeds:
            if seed.exists():merge(seed,frozen,conflicts)
        dump(base/'seed_union_conflicts.json',conflicts)
        for rt in ['m3','m4']:run(rt,src,frozen,base/('materialize-'+rt),False)
        dump(base/'seed_manifest.json',manifest(frozen))
    for rt,n in ORDER:
        dest=base/'runs'/f'{rt}-r{n}'
        cache=base/f'cache-{rt}-r{n}'
        if (dest/'command.json').exists():
            if cache.exists():remove_cache(cache)
            continue
        if cache.exists():remove_cache(cache)
        copy_tree(frozen,cache)
        run(rt,src,cache,dest,True)
        remove_cache(cache)
    if frozen.exists():remove_cache(frozen)
    print('DONE',row['repo'],flush=True)
def central():
    base=S/'central_publishing_minimal';seed=base/'frozen_repository';base.mkdir(parents=True,exist_ok=True)
    copy_tree(OUT/'seed',seed,dirs_exist_ok=True)
    for condition in ['automatic','explicit']:
        src=base/'inputs'/condition;src.mkdir(parents=True,exist_ok=True)
        execution='<executions><execution><id>injected-central-publishing</id><phase>deploy</phase><goals><goal>publish</goal></goals></execution></executions>' if condition=='explicit' else ''
        (src/'pom.xml').write_text('<project xmlns="http://maven.apache.org/POM/4.0.0"><modelVersion>4.0.0</modelVersion><groupId>org.maventwin.reproducer</groupId><artifactId>central-min</artifactId><version>1.0</version><packaging>jar</packaging><build><plugins><plugin><groupId>org.sonatype.central</groupId><artifactId>central-publishing-maven-plugin</artifactId><version>0.11.0</version><extensions>true</extensions>'+execution+'</plugin></plugins></build></project>',encoding='utf-8')
        for rt in ['m3','m4']:run(rt,src,seed,base/'raw_outputs'/condition/('materialize-'+rt),False)
    dump(base/'seed_manifest.json',manifest(seed))
    for condition in ['automatic','explicit']:
        src=base/'inputs'/condition
        for rt,n in ORDER:
            out=base/'raw_outputs'/condition/'runs'/f'{rt}-r{n}';cache=base/f'cache-{condition}-{rt}-r{n}';copy_tree(seed,cache);run(rt,src,cache,out,True);remove_cache(cache)
    remove_cache(seed)
if __name__=='__main__':
    if sys.argv[1]=='build':build()
    elif sys.argv[1]=='central':central()
    else:
        rows=[x for x in read(ROOT/'final_evidence_v1/metrics/MODEL_RESULTS_FINAL.csv') if x['model_comparable']=='MODEL_COMPARABLE']
        if sys.argv[1]=='remaining':rows=[x for x in rows if x['repo']!='apache/commons-cli']
        if len(sys.argv)>2:rows=[x for x in rows if x['repo']==sys.argv[2]]
        with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(one,rows))
