from pathlib import Path
import subprocess,sys
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[2]
here=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(here/'expand_seed_manifests.py'),str(root/'supplementary_results/supplemental_20261004')],check=True)
subprocess.run([sys.executable,str(here/'analyze_supplemental.py'),str(root),str(root/'supplementary_results/supplemental_20261004')],check=True)
subprocess.run([sys.executable,str(here/'provenance_stages.py'),str(root),str(root/'supplementary_results')],check=True)
