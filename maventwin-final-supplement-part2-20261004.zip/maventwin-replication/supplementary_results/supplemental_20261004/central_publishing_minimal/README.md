# Central Publishing model-mutation experiment

inputs/ contains the automatic-injection POM and explicit-execution POM for
Central Publishing 0.11.0. Each condition has four offline captures from the same
materialized seed. Stage traces record the observer callback, all participants
complete, the help measurement complete, and plan calculation complete. Logs
record participant activity. Calculated deploy plans identify publish presence;
no deployment is performed. ModelMutationProbe.java repeats cached-wrapper,
reacquired-wrapper and shared-build-wrapper mutation sequences twice per runtime.
raw_outputs/ retains command records and outputs; source_inspection/ provides
bytecode disassembly of the frozen runtime and plugin implementation.

Recompute all summaries from the replication workspace:

    python supplemental/final_round_20261004/reproduce_final.py .
