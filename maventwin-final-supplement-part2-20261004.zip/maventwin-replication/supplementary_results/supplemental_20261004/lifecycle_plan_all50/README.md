# Fifty-repository lifecycle-plan propagation

All 50 primary model-comparable frozen revisions are measured at the root POM.
Each runtime materializes required descriptors before freezing the shared artifact
seed. Four offline captures use fresh copies in M3/M4/M4/M3 order. The observer
calculates package, install and deploy after help:effective-pom; these phases are
never executed. Results require two identical ordered plans per runtime and
normalize Maven-4 phase aliases. Raw commands, diagnostics, models, plans and
artifact seed manifests are under raw_outputs/<repository>/. Source revision and
root-POM hash are retained in input.json. This is a separate follow-up of the
primary 50 stable model pairs; original counts and inputs are preserved.
Shared seed entries are stored once; seed_manifest_delta.json retains additions,
replacements and removals for each actual frozen seed. reproduce_final.py expands
these into byte-identical seed_manifest.json files and checks the captured hash.

Recompute all summaries from the replication workspace:

    python supplemental/final_round_20261004/reproduce_final.py .
