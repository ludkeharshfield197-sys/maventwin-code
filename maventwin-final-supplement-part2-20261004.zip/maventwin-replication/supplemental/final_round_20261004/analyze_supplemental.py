"""Regenerate lifecycle and Central Publishing summaries from captured outputs."""
from pathlib import Path
import csv,json,difflib,collections,sys
ROOT=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[2]
S=Path(sys.argv[2]) if len(sys.argv)>2 else ROOT/'supplementary_results/supplemental_20261004'
ORDER=[('m3',1),('m4',1),('m4',2),('m3',2)]
PHASE_ALIASES={'sources':'generate-sources','after:sources':'process-sources','resources':'generate-resources','after:resources':'process-resources','after:compile':'process-classes','test-sources':'generate-test-sources','after:test-sources':'process-test-sources','test-resources':'generate-test-resources','after:test-resources':'process-test-resources','after:test-compile':'process-test-classes','before:package':'prepare-package','before:integration-test':'pre-integration-test','after:integration-test':'post-integration-test'}
def read(p,delimiter=','):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline=''),delimiter=delimiter))
def write(p,rows):
    with p.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def plans(base,phase):
    values={};statuses={}
    for rt,n in ORDER:
        out=base/'runs'/f'{rt}-r{n}';p=out/'observer'/f'000-{phase}-plan.tsv';command=out/'command.json'
        if not command.exists():statuses[rt,n]='CAPTURE_INCOMPLETE';continue
        c=json.loads(command.read_text(encoding='utf-8'))
        if c['timeout']:statuses[rt,n]='TIME_LIMIT';continue
        if c['exit_code']!=0:statuses[rt,n]='MEASUREMENT_GOAL_FAILED';continue
        if not p.exists():statuses[rt,n]='PLAN_CALCULATION_FAILED';continue
        rows=read(p,'\t');values[rt,n]=[tuple(x[k] if k!='phase' else PHASE_ALIASES.get(x[k],x[k]) for k in ['groupId','artifactId','version','executionId','goal','phase']) for x in rows];statuses[rt,n]='CALCULATED_NOT_EXECUTED'
    stable={rt:all((rt,n) in values for n in [1,2]) and values[rt,1]==values[rt,2] for rt in ['m3','m4']}
    return values,statuses,stable
def lifecycle():
    primary=[x for x in read(ROOT/'final_evidence_v1/metrics/MODEL_RESULTS_FINAL.csv') if x['model_comparable']=='MODEL_COMPARABLE']
    provenance={x['repo']:('source' if x['project_pom_evidence']=='true' else 'runtime' if x['runtime_only_evidence']=='true' else 'unresolved') for x in read(ROOT/'artifacts/reviewer_revision/model/model_delta_summary.csv')}
    deltas=read(ROOT/'final_evidence_v1/MODEL_DELTAS_FINAL.csv');result=[]
    for row in primary:
        repo=row['repo'];base=S/'lifecycle_plan_all50/raw_outputs'/repo.replace('/','__');ds=[x for x in deltas if x['repo']==repo]
        for phase in ['package','install','deploy']:
            vals,status,stable=plans(base,phase);different='';count='';entities='';details=[];kind='';central_removed=''
            if all(stable.values()):
                a,b=vals['m3',1],vals['m4',1];different=a!=b;count=0;changed=set()
                for tag,i,j,k,l in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes():
                    if tag!='equal':
                        count+=max(j-i,l-k);changed.update(x[0]+':'+x[1] for x in a[i:j]+b[k:l]);details.append(dict(operation=tag,maven3=a[i:j],maven4=b[k:l]))
                entities=';'.join(sorted(changed))
                kind='IDENTICAL' if not different else 'PLUGIN_VERSION' if [x[:2]+x[3:] for x in a]==[x[:2]+x[3:] for x in b] else 'INVOCATION_SEQUENCE'
                central_removed=any(x[1]=='central-publishing-maven-plugin' and x[4]=='publish' for x in a) and not any(x[1]=='central-publishing-maven-plugin' and x[4]=='publish' for x in b)
            result.append(dict(repository=repo,commit=row['commit'],phase=phase,maven3_status=';'.join(status['m3',n] for n in [1,2]),maven4_status=';'.join(status['m4',n] for n in [1,2]),stable_maven3=stable['m3'],stable_maven4=stable['m4'],plan_equal=(not different if different!='' else ''),changed_invocation_count=count,changed_plugin_entities=entities,source_pom_linked=provenance[repo]=='source',provenance_group=provenance[repo],structural_signature_count=len({(x['category'],x['entity'],x['field']) for x in ds}),plan_difference_kind=kind,central_publish_omitted=central_removed,changes=json.dumps(details)))
    write(S/'lifecycle_plan_all50/lifecycle_plan_propagation.csv',result);write(S/'lifecycle_plan_all50/results.csv',result)
    summary={}
    for phase in ['package','install','deploy']:
        xs=[x for x in result if x['phase']==phase];e=[x for x in xs if x['plan_equal']!=''];d=[x for x in e if x['plan_equal']==False]
        summary[phase]=dict(attempted=len(xs),evaluable=len(e),different=len(d),identical=len(e)-len(d),different_repositories=[x['repository'] for x in d],version_only_repositories=[x['repository'] for x in d if x['plan_difference_kind']=='PLUGIN_VERSION'],central_publish_omitted_repositories=[x['repository'] for x in d if x['central_publish_omitted']],changed_entities=dict(collections.Counter(entity for x in d for entity in x['changed_plugin_entities'].split(';'))))
    summary['repositories']=dict(attempted=len(primary),any_evaluable=len({x['repository'] for x in result if x['plan_equal']!=''}),all_phases_evaluable=sum(all(x['plan_equal']!='' for x in result if x['repository']==r['repo']) for r in primary),any_different=len({x['repository'] for x in result if x['plan_equal']==False}))
    table=[];ablations=read(ROOT/'supplemental/MODEL_ABLATION.csv')
    for group in ['all','remove_two_common','source_linked_only']:
        ids=set(next(x['repository_ids'] for x in ablations if x['stage']==group).split(';'))
        for phase in ['package','install','deploy']:
            xs=[x for x in result if x['repository'] in ids and x['phase']==phase];table.append(dict(model_filter=group,repositories=len(ids),phase=phase,plan_evaluable=sum(x['plan_equal']!='' for x in xs),plan_different=sum(x['plan_equal']==False for x in xs)))
    write(S/'lifecycle_plan_all50/model_to_plan_table.csv',table)
    (S/'lifecycle_plan_all50/summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');return summary
def central():
    base=S/'central_publishing_minimal';rows=[];trace=[]
    for condition in ['automatic','explicit']:
        for rt,n in ORDER:
            out=base/'raw_outputs'/condition/'runs'/f'{rt}-r{n}';vals,status,stable=plans(base/'raw_outputs'/condition,'deploy')
            ps=read(out/'observer/000-deploy-plan.tsv','\t');goal=any(x['artifactId']=='central-publishing-maven-plugin' and x['goal']=='publish' for x in ps)
            rows.append(dict(condition=condition,runtime=rt,replicate=n,status=status[rt,n],deploy_publish_goal=goal,plan_stable=stable[rt]))
            for stage in ['participant-callback','participants-complete','measurement-complete','plans-complete']:
                p=out/'observer'/f'000-{stage}-plugins.tsv';plugins=read(p,'\t');cp=[x for x in plugins if x['entity']=='org.sonatype.central:central-publishing-maven-plugin'];realm=(out/'observer'/f'000-{stage}-realm.txt').read_text();log=(out/'stdout.txt').read_text(encoding='utf-8')
                trace.append(dict(condition=condition,runtime=rt,replicate=n,stage=stage,plugin_loaded=bool(cp) and '=true' in realm,extension_loaded='=true' in realm,execution_present=any(x['executionId']=='injected-central-publishing' for x in cp),goal_present=any('publish' in x['goals'] for x in cp),participant_invoked='Inspecting build with total of' in log,deploy_execution_present=any(x['entity']=='org.apache.maven.plugins:maven-deploy-plugin' and x['executionId']=='default-deploy' for x in plugins),notes='Loaded denotes the publishing participant class available in the project extension realm. Goal presence is in the model; actual deploy-plan presence is in results.csv. Callback precedes the project-scoped participant in this minimal reproducer; SessionStarted observes all afterProjectsRead callbacks complete.'))
    write(base/'results.csv',rows);write(base/'central_publishing_stage_trace.csv',trace)
    probes=[]
    for rt,n in ORDER:
        out=base/'raw_outputs/model_mutation'/f'{rt}-r{n}';c=json.loads((out/'command.json').read_text(encoding='utf-8'))
        for line in (out/'stdout.txt').read_text().splitlines():
            condition,held,model,deploy=line.split('\t');probes.append(dict(runtime=rt,replicate=n,condition=condition,exit_code=c['exit_code'],held_wrapper_executions=int(held),model_central_executions=int(model),model_deploy_executions=int(deploy)))
    write(base/'model_mutation_results.csv',probes)
    return dict(captures=len(rows),automatic={rt:[x['deploy_publish_goal'] for x in rows if x['condition']=='automatic' and x['runtime']==rt] for rt in ['m3','m4']},explicit={rt:[x['deploy_publish_goal'] for x in rows if x['condition']=='explicit' and x['runtime']==rt] for rt in ['m3','m4']},model_mutation_captures=4)
if __name__=='__main__':
    print(json.dumps(dict(lifecycle=lifecycle(),central=central()),indent=2))
