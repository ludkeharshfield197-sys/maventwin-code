from run_plans import *
base=S/'central_publishing_minimal/raw_outputs/model_mutation';classes=base/'classes';classes.mkdir(parents=True,exist_ok=True)
cp=os.pathsep.join([str(Path(RT['m3'])/'lib/*'),str(Path(RT['m3'])/'boot/*')])
subprocess.run([str(Path(RT['jdk'])/'bin/javac.exe'),'--release','17','-cp',cp,'-d',str(classes),str(D/'ModelMutationProbe.java')],check=True)
for rt,n in ORDER:
    cp=os.pathsep.join([str(classes),str(Path(RT[rt])/'lib/*'),str(Path(RT[rt])/'boot/*')])
    process([str(Path(RT['jdk'])/'bin/java.exe'),'-cp',cp,'ModelMutationProbe'],base,base/f'{rt}-r{n}',30)
    print(rt,n,(base/f'{rt}-r{n}/stdout.txt').read_text())
