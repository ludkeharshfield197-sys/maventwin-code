"""Expand compact artifact manifests into their byte-identical captured JSON files."""
from pathlib import Path,PureWindowsPath
import json,hashlib,sys
base=Path(sys.argv[1])/'lifecycle_plan_all50'
shared={x['path']:x for x in json.loads((base/'shared_seed_manifest.json').read_text())}
for p in sorted((base/'raw_outputs').glob('*/seed_manifest_delta.json')):
    delta=json.loads(p.read_text());items=shared.copy()
    for name in delta['removed_paths']:items.pop(name)
    items.update({x['path']:x for x in delta['replaced_or_added']})
    entries=[items[name] for name in sorted(items,key=PureWindowsPath)]
    data=json.dumps(entries,ensure_ascii=False,indent=2).replace('\n','\r\n').encode('utf-8')
    assert len(entries)==delta['artifact_count']
    assert hashlib.sha256(data).hexdigest()==delta['captured_manifest_sha256'],p
    p.with_name('seed_manifest.json').write_bytes(data)
print('Expanded artifact manifests exactly from shared base and per-project changes.')
