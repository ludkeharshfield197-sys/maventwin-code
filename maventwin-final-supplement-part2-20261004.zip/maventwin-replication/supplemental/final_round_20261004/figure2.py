"""Draw the primary layer populations and phase-specific plan propagation."""
from pathlib import Path
import json,sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
S=Path(sys.argv[1]);F=Path(sys.argv[2]);F.mkdir(parents=True,exist_ok=True)
summary=json.loads((S/'lifecycle_plan_all50/summary.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'pdf.fonttype':42})
fig,grid=plt.subplots(2,2,figsize=(10.3,5.7))
fig.subplots_adjust(left=.07,right=.98,top=.91,bottom=.12,wspace=.27,hspace=.45)
axes=grid.flatten()
items=[('Initial model provenance (n = 50)',[20,18,12],['Source-POM linked','Runtime/default','Initially unresolved'],['#0072B2','#009E73','#E69F00']),('Dependency graph (n = 53)',[2,51],['Different','Identical'],['#D55E00','#B7C9D6']),('Root validation (n = 47)',[36,3,1,7],['Pass/pass','Pass/fail','Fail/pass','Other/mixed'],['#009E73','#D55E00','#56B4E9','#9A7AB5'])]
for ax,(title,counts,labels,colors) in zip(axes,items):
    ax.set_title(title,fontsize=14,fontweight='bold',pad=10)
    left=0
    for count,color in zip(counts,colors):
        ax.barh(.86,count,left=left,height=.18,color=color,edgecolor='white',linewidth=1)
        if count>=6:ax.text(left+count/2,.86,str(count),ha='center',va='center',color='white' if color!='#B7C9D6' else '#152C3C',fontsize=13,fontweight='bold')
        left+=count
    ax.set_xlim(0,sum(counts));ax.set_ylim(0,1);ax.axis('off')
    ax.legend([Patch(facecolor=c) for c in colors],[f'{l}: {n}' for l,n in zip(labels,counts)],loc='upper left',bbox_to_anchor=(-.01,.73),frameon=False,fontsize=12,handlelength=1.3,labelspacing=.45)
axes[1].text(0,.10,'Both reproduce and reverse offline',fontsize=11,color='#334D5C')
axes[2].text(0,-.05,'Of three initial pass/fail records:\n2 reproduce; 1 passes on full checkout',fontsize=11,color='#334D5C')
ax=axes[3];ax.set_title('Lifecycle-plan propagation (n = 50)',fontsize=14,fontweight='bold',pad=10)
colors=['#D55E00','#B7C9D6','#D9D9D9']
for i,phase in enumerate(['package','install','deploy']):
    row=summary[phase];counts=[row['different'],row['identical'],50-row['evaluable']];left=0;y=2-i
    for count,color in zip(counts,colors):
        ax.barh(y,count,left=left,height=.48,color=color,edgecolor='white',linewidth=1);left+=count
    ax.text(51,y,f"{row['different']}/{row['evaluable']}",va='center',fontsize=12,fontweight='bold')
ax.set_yticks([2,1,0],['Package','Install','Deploy']);ax.set_xticks([]);ax.set_xlim(0,61);ax.set_ylim(-.55,2.55);ax.tick_params(length=0)
for spine in ax.spines.values():spine.set_visible(False)
ax.legend([Patch(facecolor=c) for c in colors],['Different','Identical','Unavailable'],loc='upper left',bbox_to_anchor=(-.01,-.03),frameon=False,fontsize=10,ncol=3,handlelength=1)
for ext in ['pdf','png']:fig.savefig(F/f'Figure2_layer_counts.{ext}',dpi=240,bbox_inches='tight',facecolor='white')
print('Figure 2 generated from captured plan summaries.')
