import java.util.*;
import org.apache.maven.model.*;
import org.apache.maven.project.MavenProject;
public class ModelMutationProbe {
  static Plugin find(Model m,String id){return m.getBuild().getPlugins().stream().filter(p->id.equals(p.getArtifactId())).findFirst().orElseThrow();}
  static PluginExecution execution(String id,String goal){PluginExecution e=new PluginExecution();e.setId(id);e.setPhase("deploy");e.addGoal(goal);return e;}
  public static void main(String[] args){
    for(String condition:new String[]{"cached-wrapper","reacquired-wrapper","shared-build-wrapper"}){
      Model model=new Model();model.setModelVersion("4.0.0");Build b=new Build();model.setBuild(b);
      Plugin c=new Plugin();c.setGroupId("org.sonatype.central");c.setArtifactId("central-publishing-maven-plugin");c.setVersion("0.11.0");b.addPlugin(c);
      Plugin d=new Plugin();d.setArtifactId("maven-deploy-plugin");d.addExecution(execution("default-deploy","deploy"));b.addPlugin(d);
      MavenProject project=new MavenProject(model);Model m=project.getModel();
      Build shared=m.getBuild();
      Plugin central=condition.equals("shared-build-wrapper")?shared.getPlugins().get(0):find(m,"central-publishing-maven-plugin");
      Plugin deploy=condition.equals("shared-build-wrapper")?shared.getPlugins().get(1):find(m,"maven-deploy-plugin");
      deploy.getExecutions().clear();
      if(condition.equals("reacquired-wrapper"))central=find(m,"central-publishing-maven-plugin");
      central.getExecutions().add(execution("injected-central-publishing","publish"));
      System.out.println(condition+"\t"+central.getExecutions().size()+"\t"+find(m,"central-publishing-maven-plugin").getExecutions().size()+"\t"+find(m,"maven-deploy-plugin").getExecutions().size());
    }
  }
}
