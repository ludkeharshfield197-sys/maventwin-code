package org.maventwin.observer;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.apache.maven.MavenExecutionException;
import org.apache.maven.AbstractMavenLifecycleParticipant;
import org.apache.maven.eventspy.EventSpy;
import org.apache.maven.execution.*;
import org.apache.maven.project.MavenProject;
import org.apache.maven.model.*;
import org.apache.maven.model.io.xpp3.MavenXpp3Writer;
import org.apache.maven.lifecycle.*;
import org.apache.maven.lifecycle.internal.*;
import org.apache.maven.plugin.*;
import org.apache.maven.plugin.prefix.NoPluginFoundForPrefixException;
import org.apache.maven.plugin.version.PluginVersionResolutionException;
/** Read-only stage capture; the three calculated lifecycle phases are never executed. */
public class ObserverStages extends AbstractMavenLifecycleParticipant implements EventSpy {
  public LifecycleExecutionPlanCalculator calculator;
  private Path dir(){return Paths.get(System.getProperty("maventwin.observer.output"));}
  private String cell(Object x){return x==null?"":x.toString().replace("\t"," ").replace("\r"," ").replace("\n"," ");}
  private void capture(MavenSession session,String stage) throws IOException {
    Files.createDirectories(dir());int i=0;
    for(MavenProject p:session.getProjects()){
      String stem=String.format("%03d",i++);
      try(Writer w=Files.newBufferedWriter(dir().resolve(stem+"-"+stage+"-model.xml"),StandardCharsets.UTF_8)){new MavenXpp3Writer().write(w,p.getModel());}
      try(BufferedWriter w=Files.newBufferedWriter(dir().resolve(stem+"-"+stage+"-plugins.tsv"),StandardCharsets.UTF_8)){
        w.write("entity\tversion\textension\texecutionId\tphase\tgoals\n");
        for(Plugin plugin:p.getBuildPlugins()){
          w.write(cell(plugin.getKey())+"\t"+cell(plugin.getVersion())+"\t"+plugin.isExtensions()+"\t\t\t\n");
          for(PluginExecution e:plugin.getExecutions())w.write(cell(plugin.getKey())+"\t"+cell(plugin.getVersion())+"\t"+plugin.isExtensions()+"\t"+cell(e.getId())+"\t"+cell(e.getPhase())+"\t"+cell(e.getGoals())+"\n");
        }
      }
      boolean centralRealm=p.getClassRealm()!=null && p.getClassRealm().getResource("org/sonatype/central/publisher/plugin/DeployLifecycleParticipant.class")!=null;
      Files.writeString(dir().resolve(stem+"-"+stage+"-realm.txt"),"central_participant_class_available="+centralRealm+"\n",StandardCharsets.UTF_8);
    }
  }
  @Override public void afterProjectsRead(MavenSession session) throws MavenExecutionException{
    try{capture(session,"participant-callback");}catch(IOException e){throw new MavenExecutionException("Stage capture failed",e);}
  }
  @Override public void init(EventSpy.Context context){}
  @Override public void close(){}
  @Override public void onEvent(Object event) throws IOException{
    if(event instanceof ExecutionEvent && ((ExecutionEvent)event).getType()==ExecutionEvent.Type.SessionStarted)capture(((ExecutionEvent)event).getSession(),"participants-complete");
  }
  @Override public void afterSessionEnd(MavenSession session) throws MavenExecutionException{
    try{
      capture(session,"measurement-complete");int i=0;
      for(MavenProject p:session.getProjects()){
        String stem=String.format("%03d",i++);MavenProject previous=session.getCurrentProject();session.setCurrentProject(p);
        try{
          for(String phase:new String[]{"package","install","deploy"}){
            try{
              MavenExecutionPlan plan=calculator.calculateExecutionPlan(session,p,List.of(new LifecycleTask(phase)),false);
              try(BufferedWriter w=Files.newBufferedWriter(dir().resolve(stem+"-"+phase+"-plan.tsv"),StandardCharsets.UTF_8)){
                w.write("order\tgroupId\tartifactId\tversion\texecutionId\tgoal\tphase\n");int n=0;
                for(MojoExecution m:plan.getMojoExecutions())w.write((n++)+"\t"+cell(m.getGroupId())+"\t"+cell(m.getArtifactId())+"\t"+cell(m.getVersion())+"\t"+cell(m.getExecutionId())+"\t"+cell(m.getGoal())+"\t"+cell(m.getLifecyclePhase())+"\n");
              }
            }catch(PluginNotFoundException|PluginResolutionException|LifecyclePhaseNotFoundException|PluginDescriptorParsingException|MojoNotFoundException|InvalidPluginDescriptorException|NoPluginFoundForPrefixException|LifecycleNotFoundException|PluginVersionResolutionException e){
              try(PrintWriter w=new PrintWriter(Files.newBufferedWriter(dir().resolve(stem+"-"+phase+"-error.txt"),StandardCharsets.UTF_8))){e.printStackTrace(w);}
            }
          }
        }finally{session.setCurrentProject(previous);}
      }
      capture(session,"plans-complete");
    }catch(IOException e){throw new MavenExecutionException("Stage capture failed",e);}
  }
}
