# MavenTwin final supplementary experiments — 2026-10-04

Download the three existing replication parts and all final-supplement parts;
extract them into one directory, then enter maventwin-replication/.
Recompute new lifecycle, minimal-publishing and provenance summaries offline:

    python supplemental/final_round_20261004/reproduce_final.py .

Recompute the primary and previous supplementary results:

    python supplemental/reproduce_report.py --workspace . --experiment-root supplementary_results

New execution commands, stage captures, ordered plans, materialization manifests
and CSVs are in supplementary_results/supplemental_20261004/. Experiment folders
include README.md, commands.json, results.csv, raw_outputs/ and sha256.txt.
Absolute local paths are represented by ${WORKSPACE}, ${EXPERIMENT_ROOT} and
${USER_HOME}; recorded hashes describe captured artifact bytes before path
substitution. sha256.txt hashes the distributed files.

For new measurements, configure protocol/runtime_paths.json and settings,
materialize the recorded artifact seed and snapshots, and set
MAVENTWIN_WORKSPACE_ROOT and MAVENTWIN_EXPERIMENT_ROOT. Place the provided
original seed under supplementary_results/seed/; binary caches are obtained
separately using the recorded artifact manifests. Then run:

    python supplemental/final_round_20261004/run_plans.py build
    python supplemental/final_round_20261004/run_plans.py all
    python supplemental/final_round_20261004/run_plans.py central
    python supplemental/final_round_20261004/run_mutation_probe.py

The primary runtimes remain Maven 3.9.16 and Maven 4.0.0-rc-7, JDK 21, Windows.
The publishing phases are calculated, never executed. The release includes code
and necessary deidentified experimental materials; no manuscript is included.
